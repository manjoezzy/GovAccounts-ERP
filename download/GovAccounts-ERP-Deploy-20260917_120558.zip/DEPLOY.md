# GovAccounts ERP — Deployment Guide

## Vercel Deployment (Recommended)

### 1. Push to GitHub
```bash
git init && git add -A && git commit -m "initial"
git remote add origin https://github.com/YOUR_USER/GovAccounts-ERP.git
git push -u origin main
```

### 2. Connect to Vercel
1. Go to https://vercel.com/new
2. Import your GitHub repository
3. Framework Preset: **Next.js**
4. Root Directory: `.` (default)

### 3. Set Environment Variables on Vercel
Add these in **Settings → Environment Variables**:

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | **Yes** | Turso/libSQL connection URL (e.g. `libsql://your-db.turso.io`) |
| `TURSO_AUTH_TOKEN` | If using Turso | Turso database auth token |
| `NEXTAUTH_SECRET` | **Yes** | Random secret for JWT signing (`openssl rand -base64 32`) |
| `NEXTAUTH_URL` | **Yes** | Your Vercel URL (e.g. `https://gov-accounts-erp.vercel.app`) |
| `GOOGLE_CLIENT_ID` | **Yes** | Google OAuth client ID |
| `GOOGLE_CLIENT_SECRET` | **Yes** | Google OAuth client secret |

### 4. Set Up Turso Database (Cloud SQLite)
```bash
npm install -g turso
turso auth login
turso db create gov-accounts-erp
turso db shell gov-accounts-erp < prisma/schema.sql
```

Get the connection URL and auth token:
```bash
turso db show gov-accounts-erp --url
turso db tokens create gov-accounts-erp
```

### 5. Deploy
Vercel will auto-deploy on push. First deploy takes ~2-3 minutes.

## Local Development

```bash
npm install
npx prisma generate
npx prisma db push
npm run db:seed    # Optional: seed with sample data
npm run dev
```

Open http://localhost:3000

## Without Turso (Local SQLite only)
For local-only development, the default `DATABASE_URL=file:./db/dev.db` works out of the box.
For Vercel, you **must** use a cloud database (Turso recommended).
